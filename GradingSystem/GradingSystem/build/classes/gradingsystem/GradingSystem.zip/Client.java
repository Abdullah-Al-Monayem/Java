
package gradingsystem;


public class Client {
    
    String name, Address;

    public Client() {
    }

   

    public Client(String name, String Address) {
        this.name = name;
        this.Address = Address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

   
    
    
    
}


